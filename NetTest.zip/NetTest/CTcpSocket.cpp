#include "CTcpSocket.h"
#include "PubFunc.h"
#include <stdio.h>

CTcpSocket::CTcpSocket(QObject *parent) : QTcpSocket(parent)
{
    connect(this,SIGNAL(readyRead()),this,SLOT(slotReadData()));
    connect(this,SIGNAL(disconnected()),this,SLOT(slotDisconnected()));
}

/************************************************************************
*函数名:	SaveSocketDecriptor
*概述:将该套接字的描述符保存到成员变量，在TCPSever中要用到。
*参数：无
*返回值：无
************************************************************************/
void CTcpSocket::SaveSocketDecriptor()
{
    mSocketDecriptor = this->socketDescriptor();
}

/************************************************************************
*函数名:	DisplaySocketDecriptor
*概述:打印套接字描述符(测试)。
*参数：无
*返回值：无
************************************************************************/
void CTcpSocket::DisplaySocketDecriptor()
{
    qDebug()<<"socketDescriptor:"<<this->socketDescriptor();
}

bool CTcpSocket::SendData(unsigned char* sendBuf,int nSendLen)
{
    qint64 nRet = this->write((char*)sendBuf,nSendLen);
    if( -1 == nRet )
        return false;

    return true;
}

//slots
/************************************************************************
*函数名:	slotReadData
*概述:接收数据报文。
*参数：无
*返回值：无
************************************************************************/
void CTcpSocket::slotReadData()
{
    if( this->bytesAvailable() > sizeof(FrameHead) )
    {
        QByteArray rcvAry = this->readAll();
        //将获取到的报文添加到缓存中
        mCacheAry.append(rcvAry);
        //获取缓存长度
        int nCacheLen = mCacheAry.length();

        //解析缓存
        int nMaxRcvBufLen = nCacheLen;
        unsigned char cRcvBuf[COMMAXLEN] = {'0'};
        if( nCacheLen >= COMMAXLEN )
        {
            nMaxRcvBufLen = COMMAXLEN;
        }
        memmove(cRcvBuf,rcvAry.data(),nMaxRcvBufLen);

        if( 0xAA != cRcvBuf[0] )//帧头不正确
        {
            qDebug()<<cRcvBuf[0]<<"|帧头不正确";
        }
        //查找帧尾
        int nTotalLen = 0;
        bool bFindTail = false;
        for( ;nTotalLen<nMaxRcvBufLen;nTotalLen++ )
        {
            if( 0xA5 == cRcvBuf[nTotalLen] )
            {
                ++nTotalLen;
                bFindTail = true;
                qDebug()<<nTotalLen<<nCacheLen;
                break;
            }
        }
        //如果没有找到帧尾，则跳过
        if( false == bFindTail )
            return;

        //计算校验位
        unsigned char cCheck = cRcvBuf[1];
        for(int i=2;i<nTotalLen-2;i++)
        {
            cCheck = cCheck^cRcvBuf[i];
        }
        //比较校验位
        if( cCheck != cRcvBuf[nTotalLen-2] )// 校验位判断
        {
            qDebug()<<"校验位错误";
            mCacheAry.remove(0,nTotalLen);//将错误信息丢弃
            return;
        }
        //帧头
        FrameHead head;
        memmove((unsigned char*)&head,cRcvBuf,sizeof(FrameHead));
        //报头信息(帧头、目的地址、源地址、类型)
        qDebug()<<head.cHead<<head.cDesAdd<<head.cSrcAdd<<head.cType;

        //信息区
        short nInfoLen = 0;//信息长度=长度位(2)+信息区位长度(N)
        unsigned char cInfoBuf[COMMAXLEN] = {'0'};//解码后的信息区缓存
        RecvBufChange(cRcvBuf,cInfoBuf,nTotalLen,nInfoLen);
        switch (head.cType) {
        case 0x32:
        {
            MidInfo midInfo;
            memmove((unsigned char*)&midInfo,cInfoBuf+sizeof(short),sizeof(MidInfo));
            qDebug()<<midInfo.cLDState<<midInfo.cWorkMode<<midInfo.cPulseInput<<midInfo.cOLMid<<midInfo.cDSMid;
        }
            break;
        case 0x33:
            break;
        }
        //将解析过得信息从缓存中清除
        mCacheAry.remove(0,nTotalLen);

        //eg:
        emit signalSendData(mSocketDecriptor,(unsigned char*)&head,sizeof(FrameHead));
    }
}

void CTcpSocket::slotDisconnected()
{
    qDebug()<<"CTcpSocket::slotDisconnected()";
    //emit signalDisconnected(this->socketDescriptor());
    //发送断开连接信号
    emit signalDisconnected(mSocketDecriptor);
}
