#ifndef CTCPSERVER_H
#define CTCPSERVER_H

#include <QMap>
#include <QTcpServer>
#include <QTcpSocket>
#include "DataStruct.h"

class CTcpSocket;
class CTcpServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit CTcpServer(QObject *parent = nullptr); 
    bool StartListen(QString strServerIP,quint16 nServerPort);
    bool SendData(qintptr handle,LDStateInfo &msgData);
    bool SendData(qintptr handle,unsigned char* sendBuf,int nSendLen);
    void StopListen();
protected:
    void incomingConnection(qintptr handle);

private:
    QMap<qintptr,CTcpSocket*>mClientsMap;


signals:

public slots:

private slots:
    void slotReadData(qintptr handle,unsigned char* rcvBuf,int nRcvLen);
    void slotDisconnected(qintptr handle);

};

class CTcpSocket : public QTcpSocket
{
    Q_OBJECT
public:
    explicit CTcpSocket(QObject *parent = nullptr);

    //Only used in TcpServer
    void SaveSocketDecriptor();
    void DisplaySocketDecriptor();
    bool SendData(unsigned char* sendBuf,int nSendLen);
private:
    //套接字描述符
    qintptr mSocketDecriptor;
    //接收数据缓存
    QByteArray mCacheAry;

signals:
    //Only used in TcpServer
    void signalSendData(qintptr handle,unsigned char* sendBuf,int nSendLen);
    void signalDisconnected(qintptr handle);

public slots:
    void slotReadData();
    void slotDisconnected();
};

#endif // CTCPSERVER_H
