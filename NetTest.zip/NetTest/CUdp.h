#ifndef CUDP_H
#define CUDP_H

#include <QTimer>
#include <QObject>
#include <QUdpSocket>
#include <QHostAddress>
#include "DataStruct.h"

class CUdp : public QObject
{
    Q_OBJECT
public:
    explicit CUdp(QObject *parent = nullptr);
    bool Bind(QHostAddress localHost,quint16 nLocalPort);
    bool SendData(QHostAddress desHost,quint16 nDesPort,unsigned char* sendBuf,int nSendLen);
    //TEST
    void StartTest();

private:
    bool processTheDatagram(QHostAddress srcHost,quint16 nSrcPort,QByteArray &datagram);

 private:
    QUdpSocket* m_pUdpCommon;//通用的UDP对象

    //TEST
    bool m_bFeedback;
    QTimer* m_pTimer;
signals:

public slots:

private slots:
    void Connected();
    void Disconnected();
    void DisplayError(QAbstractSocket::SocketError err);
    void ReadPendingDatagrams();

    //TEST
    void SendDataTest();
};

#endif // CUDP_H
