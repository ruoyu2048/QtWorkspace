#ifndef CTCPCLIENT_H
#define CTCPCLIENT_H

#include <QObject>
#include <QTimer>
#include <QTcpSocket>
#include "DataStruct.h"

class CTcpClient : public QObject
{
    Q_OBJECT
public:
    explicit CTcpClient(QObject *parent = nullptr);
    bool ConnectToHost(QString strServerIP,quint16 nServerPort);
    bool SendData(unsigned char* sendBuf,int nSendLen);
    void Close();
private:
    void StartTest();

private:
    QByteArray  mCacheAry;
    QTcpSocket* m_pTSClient;
    //TEST
    QTimer* m_pTimer;
    qintptr mSocketDecriptor;
signals:
    void UpdateConnectState(QString strConnectState);
public slots:

private slots:
    void ReadData();
    void Connected();
    void Disconnected();
    void DisplayError(QAbstractSocket::SocketError socketError);

    //TEST
    void SendDataTest();
};

#endif // CTCPCLIENT_H
