#ifndef DATASTRUCT_H
#define DATASTRUCT_H


struct FrameHead{
    unsigned char cHead;             //帧头
    unsigned char cDesAdd;           //目的地址
    unsigned char cSrcAdd;           //原地址
    unsigned char cType;             //消息类型
    //short nLen;
    FrameHead(){
        //memset(this,0,sizeof(FrameHead));
        memset(&cHead,0,sizeof(FrameHead));
        cHead = 0xAA;
    }
};

struct FrameTail{
    char cCheck;        //校验位
    char cTail;         //包尾
    FrameTail(){
        //memset(this,0,sizeof(FrameTail));
        memset(&cCheck,0,sizeof(FrameTail));
        cTail = 0xA5;
    }
};

//中频源(Mid)
struct MidInfo{
    char cLDState;          //雷达状态
    char cWorkMode;         //工作模式
    char cPulseInput;       //脉冲输入
    char cOLMid;            //中频源输出幅度(Output Level of Mid)
    char cDSMid;            //设备状态(Device of Mid)
    char cReserve[4];       //备用
    MidInfo(){
        //memset(this,0,sizeof(LDInfoArea));
        memset(&cLDState,0,sizeof(MidInfo));
    }
};

//源及变频组件(Source component)
struct SrcCompInfo{
    char cLDState;          //雷达状态
    char cFPSrc;            //频点(Frequency Point of SRC)
    char cLockCMD;          //锁定指示
    char cOLSrc;            //输出幅度(Output Level of Src)
    char cDSSrc;            //设备状态(Device State of Src)
    char cReserve[4];       //备用
    SrcCompInfo(){
        //memset(this,0,sizeof(LDInfoArea));
        memset(&cLDState,0,sizeof(SrcCompInfo));
    }
};

//发射组件(Transmitted component)
struct TransCompInfo{
    char cLDState;          //雷达状态
    char cOFTrans;          //开关状态(On or Off state of Trans)
    char cTransPower[8];    //发射功率(Transmitted Power)
    char cPadValue[8];      //衰减值
    char cPSValue[8];       //移相值（phase shift value）
    char cCompTemp[8];      //组件温度(The component temperature)
    char cCompCurState[8];  //组件电流(The component current state)
    char cOutputPower[8];   //输出功率值
    char sDSTrans;          //设备状态
    char cReserve[4];       //备用
    TransCompInfo(){
        //memset(this,0,sizeof(LDInfoArea));
        memset(&cLDState,0,sizeof(TransCompInfo));
    }
};

//校正源(Check source)
struct CheckSrcInfo{
    char cLDState;          //雷达状态
    char cOFCheck;          //开关状态
    char cFPCheck;          //频点
    char cOLCheck;          //输出幅度
    char cDSCheck;          //设备状态
    char cReserve[4];       //备用
    CheckSrcInfo(){
        //memset(this,0,sizeof(LDInfoArea));
        memset(&cLDState,0,sizeof(CheckSrcInfo));
    }
};

//处理终端(processing terminal)
struct ProcessTermInfo{
    char cLDState;       //雷达状态
    char cATemp;        //机箱内A点温度
    char cBTemp;        //机箱内B点温度
    float f1Voltage;    //电源1的电压值
    float f1Current;    //电源1的电流值
    float f2Voltage;    //电源2的电压值
    float f2Current;    //电源2的电流值
    float f3Voltage;    //电源3的电压值
    float f3Current;    //电源3的电流值
    char cCPU;          //CPU使用率
    char cRAM;          //内存使用率
    char cHard;         //硬盘占用率
    char cWorkState;    //终端工作状态
    char cReserve[4];   //备用
    ProcessTermInfo(){
        //memset(this,0,sizeof(LDInfoArea));
        memset(&cLDState,0,sizeof(ProcessTermInfo));
    }
};

struct LDInfoArea{
    char cLDState;          //雷达状态
    //中频源(Mid)
    char cWorkMode;         //工作模式
    char cPulseInput;       //脉冲输入
    char cOLMid;            //中频源输出幅度(Output Level of Mid)
    char cDSMid;            //设备状态(Device of Mid)

    //源及变频组件(Src)
    char cFPSrc;            //频点(Frequency Point of SRC)
    char cLockCMD;          //锁定指示
    char cOLSrc;            //输出幅度(Output Level of Src)
    char cDSSrc;            //设备状态(Device State of Src)

    //发射组件(Trans)
    char cOFTrans;          //开关状态(On or Off state of Trans)
    char cTransPower[8];    //发射功率(Transmitted Power)
    char cPadValue[8];      //衰减值
    char cPSValue[8];       //移相值（phase shift value）
    char cCompTemp[8];      //组件温度(The component temperature)
    char cCompCurState[8];  //组件电流(The component current state)
    char cOutputPower[8];   //输出功率值
    char sDSTrans;          //设备状态

    //校正源(Check)
    char cOFCheck;          //开关状态
    char cFPCheck;          //频点
    char cOLCheck;          //输出幅度
    char cDSCheck;          //设备状态

    //AD采集板1
    //AD采集板2
    //AD采集板3
    //DSP1
    //DSP2
    //FPGA
    //ARM监控板
    //处理终端
    //座体

    //处理终端(processing terminal)
    char cATemp;        //机箱内A点温度
    char cBTemp;        //机箱内B点温度
    float f1Voltage;    //电源1的电压值
    float f1Current;    //电源1的电流值
    float f2Voltage;    //电源2的电压值
    float f2Current;    //电源2的电流值
    float f3Voltage;    //电源3的电压值
    float f3Current;    //电源3的电流值
    char cCPU;          //CPU使用率
    char cRAM;          //内存使用率
    char cHard;         //硬盘占用率
    char cWorkState;    //终端工作状态

    char cReserve[4];   //备用

    LDInfoArea(){
        //memset(this,0,sizeof(LDInfoArea));
        memset(&cLDState,0,sizeof(LDInfoArea));
    }
};

struct LDStateInfo{
    FrameHead head;
    FrameTail tail;
};

#endif // DATASTRUCT_H
