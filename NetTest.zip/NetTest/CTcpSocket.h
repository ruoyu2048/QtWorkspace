#ifndef CTCPSOCKET_H
#define CTCPSOCKET_H

//#include <QObject>
#include <QTcpSocket>
#include "DataStruct.h"


class CTcpSocket : public QTcpSocket
{
    Q_OBJECT
public:
    explicit CTcpSocket(QObject *parent = nullptr);

    //Only used in TcpServer
    void SaveSocketDecriptor();
    void DisplaySocketDecriptor();
    bool SendData(unsigned char* sendBuf,int nSendLen);
private:
    //套接字描述符
    qintptr mSocketDecriptor;
    //接收数据缓存
    QByteArray mCacheAry;

signals:
    //Only used in TcpServer
    void signalSendData(qintptr handle,unsigned char* sendBuf,int nSendLen);
    void signalDisconnected(qintptr handle);

public slots:
    void slotReadData();
    void slotDisconnected();
};

#endif // CTCPSOCKET_H
