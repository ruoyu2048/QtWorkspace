#ifndef ILOGMANAGE_H
#define ILOGMANAGE_H
#include <QWidget>
#include <QtPlugin>
#define LogManageInterface_iid "io.qt.LogManagePlugin"

class ILogManage
{
public:
    virtual ~ILogManage() {}
    virtual ILogManage* Clone()=0;
    virtual QObject* CreateInstance()=0;
};


Q_DECLARE_INTERFACE(ILogManage, LogManageInterface_iid)
#endif // ILOGMANAGE_H
