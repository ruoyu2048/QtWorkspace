#include "LogManage.h"
#include "ui_LogManage.h"
#include <QDebug>
#include <QtPlugin>
#include <QPluginLoader>

LogManage::LogManage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::LogManage)
{
    ui->setupUi(this);

//    QAction *pAct = new QAction(this);
//    pAct->setText(tr("Copy to clipboard"));
//    pAct->setIcon(QIcon(QStringLiteral(":/images/copy.png")));
//    //connect(copyEscapedPatternAction, &QAction::triggered, this, &RegularExpressionDialog::copyEscapedPatternToClipboard);


//    QPushButton* pBtn = new QPushButton("AAA");
//    ui->lineEdit->setTextMargins(0,0,pBtn->width(),0);
//    QHBoxLayout *layout=new QHBoxLayout();
//    layout->setContentsMargins(0,5,0,5);//设置外边距
//    //以右对齐的方式添加QWidget
//    layout->addWidget(pBtn,0,Qt::AlignRight);
//    ui->lineEdit->setLayout(layout);
//    ui->lineEdit->addAction(pAct, QLineEdit::TrailingPosition);
//    ui->lineEdit->setClearButtonEnabled(true);

//   m_pMainLayout = new QHBoxLayout(this);
//   this->setLayout(m_pMainLayout);
//   m_pBtn = new QPushButton("AAA",this);
//   m_pBtn->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
//   m_pMainLayout->addWidget(m_pBtn);

   m_pMainLayout = NULL;

   m_pGBSearch = NULL;
   m_pGBHALayout = NULL;
   m_pGBHBLayout = NULL;

   m_pLBDevName = NULL;
   m_pLEDevName = NULL;
   m_pLBTime = NULL;
   m_pDEStart = NULL;
   m_pLBTo = NULL;
   m_pDEEnd = NULL;

   m_pBtnSearch = NULL;
   m_pBtnReset = NULL;

   m_pBtnHLayout = NULL;
   m_pBtnFirst = NULL;
   m_pBtnNext = NULL;
   m_pBtnPrev = NULL;
   m_pBtnLast = NULL;
   m_pCoBRowNum = NULL;
   m_pLBTotal = NULL;
   m_pLBIndex = NULL;
   m_pBtnSpacer = NULL;

   m_nAllPageCnt = 0;
   m_nCurPageIdx = 0;
   m_pLogTableView = NULL;
   m_pLogTableModel = NULL;

   InitMainWindow();
   Connections();
}

LogManage::~LogManage()
{
    delete ui;
}

bool LogManage::loadPlugin()
{
    // 加载插件，取得实例
    QPluginLoader loader(QString("LogManagePlugin.dll")) ;
    QObject* pObject = loader.instance();
    if( NULL != pObject )
    {
        m_pILogManage = qobject_cast<ILogManage*>(pObject) ;
        qDebug()<<"Load LogManagePlugin.dll Sucessfull !";
        return true;
    }
    qDebug()<<"Load LogManagePlugin.dll failed !";
    return false;
}


void LogManage::InitMainWindow()
{
    this->setWindowTitle(tr("日志管理"));
    this->showMaximized();
    m_pMainLayout = new QVBoxLayout(this);
    this->setLayout(m_pMainLayout);

    InitGroupBox();
    InitButtons();
    InitLogView();

    if( NULL != m_pGBHALayout )
        m_pMainLayout->addLayout(m_pGBHALayout);
    if( NULL != m_pBtnHLayout )
        m_pMainLayout->addLayout(m_pBtnHLayout);
    if( NULL != m_pLogTableView )
        m_pMainLayout->addWidget(m_pLogTableView);

    m_DB.OpenDB("Test.db");
}

void LogManage::InitGroupBox()
{
    //GroupBox
    m_pGBSearch = new QGroupBox(this);
    m_pGBHALayout = new QHBoxLayout();
    m_pGBHBLayout = new QHBoxLayout();

    m_pLBDevName = new QLabel(tr("设备名称:"),m_pGBSearch);
    m_pLBDevName->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    m_pLEDevName = new QLineEdit(m_pGBSearch);
    m_pLEDevName->setClearButtonEnabled(true);
    m_pLEDevName->setMinimumWidth(360);
    m_pLEDevName->setMaximumWidth(540);

    m_pLBTime = new QLabel(tr("起止时间:"),m_pGBSearch);
    m_pLBTime->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pDEStart = new QDateEdit(m_pGBSearch);
    m_pDEStart->setDate(QDate::currentDate());
    m_pDEStart->setCalendarPopup(true);
    m_pDEStart->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pLBTo = new QLabel(tr("至"),m_pGBSearch);
    m_pLBTo->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pDEEnd = new QDateEdit(m_pGBSearch);
    m_pDEEnd->setDate(QDate::currentDate());
    m_pDEEnd->setCalendarPopup(true);
    m_pDEEnd->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pGBSpacer = new QSpacerItem(20,20,QSizePolicy::Expanding,QSizePolicy::Minimum);

    m_pBtnSearch = new QPushButton(tr("查询"),m_pGBSearch);
    m_pBtnSearch->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pBtnReset = new QPushButton(tr("重置"),m_pGBSearch);
    m_pBtnReset->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pGBHBLayout->addWidget(m_pLBDevName);
    m_pGBHBLayout->addWidget(m_pLEDevName,3);
    m_pGBHBLayout->addWidget(m_pLBTime);
    m_pGBHBLayout->addWidget(m_pDEStart);
    m_pGBHBLayout->addWidget(m_pLBTo);
    m_pGBHBLayout->addWidget(m_pDEEnd);
    m_pGBHBLayout->addWidget(m_pBtnSearch);
    m_pGBHBLayout->addWidget(m_pBtnReset);
    m_pGBSearch->setLayout(m_pGBHBLayout);

    m_pGBHALayout->addWidget(m_pGBSearch);
    m_pGBHALayout->addSpacerItem(m_pGBSpacer);

}

void LogManage::InitButtons()
{
    //Buttons
    m_pBtnHLayout = new QHBoxLayout();

    m_pBtnFirst = new QPushButton(tr("首页"),this);
    m_pBtnFirst->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pBtnNext = new QPushButton(tr("下一页"),this);
    m_pBtnNext->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pBtnPrev = new QPushButton(tr("上一页"),this);
    m_pBtnPrev->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pBtnLast = new QPushButton(tr("末页"),this);
    m_pBtnLast->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pCoBRowNum= new QComboBox(this);
    m_pCoBRowNum->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);
    m_pCoBRowNum->addItem(QString("15"));
    m_pCoBRowNum->addItem(QString("30"));

    m_pLBTotal = new QLabel(tr("共0项"),this);
    m_pLBTotal->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pLBIndex = new QLabel(tr("第0页(共0页)"),this);
    m_pLBIndex->setSizePolicy(QSizePolicy::Fixed,QSizePolicy::Fixed);

    m_pBtnSpacer = new QSpacerItem(20,20,QSizePolicy::Expanding,QSizePolicy::Minimum);

    m_pBtnHLayout->addWidget(m_pBtnFirst);
    m_pBtnHLayout->addWidget(m_pBtnNext);
    m_pBtnHLayout->addWidget(m_pBtnPrev);
    m_pBtnHLayout->addWidget(m_pBtnLast);
    m_pBtnHLayout->addWidget(m_pCoBRowNum);
    m_pBtnHLayout->addWidget(m_pLBTotal);
    m_pBtnHLayout->addWidget(m_pLBIndex);
    m_pBtnHLayout->addSpacerItem(m_pBtnSpacer);
}

void LogManage::InitLogView()
{
    m_pLogTableView = new QTableView(this);
    //m_pLogTableView->setShowGrid(true);
    m_pLogTableView->setAutoFillBackground(true);
    m_pLogTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_pLogTableView->setSelectionMode(QAbstractItemView::ExtendedSelection);
    m_pLogTableView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

//    QString strHeaderQss = "QHeaderView::section { background:green; color:white;min-height:3em;}";
//    m_pLogTableView->setStyleSheet(strHeaderQss);

    QStringList modelHeaders;
    modelHeaders<<tr("A")<<tr("B")<<tr("C")<<tr("D")<<tr("E")/*<<tr("操作")*/;
    m_pLogTableModel = new LogTableModel(this);
    m_pLogTableModel->SetTableHeaders(modelHeaders);
    m_pLogTableView->setModel(m_pLogTableModel);
}

void LogManage::Connections()
{
    connect(m_pBtnSearch,SIGNAL(clicked()),this,SLOT(BtnSearchClicked()));
    connect(m_pBtnReset,SIGNAL(clicked()),this,SLOT(BtnResetClicked()));
    connect(m_pBtnFirst,SIGNAL(clicked()),this,SLOT(BtnFirstClicked()));
    connect(m_pBtnNext,SIGNAL(clicked()),this,SLOT(BtnNextClicked()));
    connect(m_pBtnPrev,SIGNAL(clicked()),this,SLOT(BtnPrevClicked()));
    connect(m_pBtnLast,SIGNAL(clicked()),this,SLOT(BtnLastClicked()));
    connect(m_pCoBRowNum,SIGNAL(currentIndexChanged(int)),this,SLOT(ComBRowNumChanged(int)));
}

void LogManage::UpdateAllPageCountInfo()
{
    m_nCurPageIdx = 0;
    //获取每页要显示的日志行数
    m_nMaxRowNum = m_pCoBRowNum->currentText().toInt();
    //获取查询到的所有日志条数
    m_nCurAllRow = m_pLogTableView->model()->rowCount();
    //计算总页数
    if( 0 == m_nCurAllRow%m_nMaxRowNum )
        m_nAllPageCnt = m_nCurAllRow/m_nMaxRowNum;
    else
        m_nAllPageCnt = m_nCurAllRow/m_nMaxRowNum + 1;
}

void LogManage::UpdateTableDisplay()
{
    if( m_nAllPageCnt > 0 )
    {
        bool bDivisiable = false;
        //判断日志总条数能否被最大显示条数整除
        if( 0 == m_nCurAllRow%m_nMaxRowNum )
            bDivisiable = true;

        if( true == bDivisiable )
        {
            //设置当前日志显示状态
            for( int i=0; i<m_nCurAllRow; i++ )
            {
                if( (i >= m_nCurPageIdx*m_nMaxRowNum) && (i < (m_nCurPageIdx+1)*m_nMaxRowNum))
                    m_pLogTableView->setRowHidden(i,false);
                else
                    m_pLogTableView->setRowHidden(i,true);
            }
        }
        else
        {
            //设置当前日志显示状态
            for( int i=0; i<m_nCurAllRow; i++ )
            {
                if( m_nCurPageIdx < m_nAllPageCnt-1 )
                {
                    if( (i >= m_nCurPageIdx*m_nMaxRowNum) && (i < (m_nCurPageIdx+1)*m_nMaxRowNum))
                        m_pLogTableView->setRowHidden(i,false);
                    else
                        m_pLogTableView->setRowHidden(i,true);
                }
                else
                {
                    if( i >= m_nCurPageIdx*m_nMaxRowNum )
                        m_pLogTableView->setRowHidden(i,false);
                    else
                        m_pLogTableView->setRowHidden(i,true);
                }
            }
        }
        UpdateLablePageInfo();
    }
}

void LogManage::UpdateLablePageInfo()
{
    QString strLBTotal = QString(tr("共%1项").arg(m_nCurAllRow));
    m_pLBTotal->setText(strLBTotal);

    QString strLBIndex = QString(tr("第%1页(共%2页)")).arg(m_nCurPageIdx+1).arg(m_nAllPageCnt);
    m_pLBIndex->setText(strLBIndex);
}

//private slots:
void LogManage::BtnSearchClicked()
{
    loadPlugin();
    m_nCurPageIdx = 0;
    QString strDevName = m_pLEDevName->text();
    QString strTStart = m_pDEStart->date().toString("yyyy-MM-dd");
    QString strTEnd = m_pDEEnd->date().toString("yyyy-MM-dd");

    //执行查询语句
    QList<QStringList>modelDate;
    QString strSelect("select * from student");
    m_DB.Select(strSelect,modelDate);
    //将查询结果放入model中
    m_pLogTableModel->SetModelData(modelDate);

    UpdateAllPageCountInfo();
    UpdateTableDisplay();
}

void LogManage::BtnResetClicked()
{
    m_nCurPageIdx = 0;
    m_nAllPageCnt = 0;

    m_pLEDevName->clear();
    m_pDEStart->setDate(QDate::currentDate());
    m_pDEEnd->setDate(QDate::currentDate());
    m_pLogTableView->model()->removeRows(0,m_nCurAllRow);
    //m_pLogTableView->reset();
    m_pLogTableModel->ClearModelData();
}

void LogManage::BtnFirstClicked()
{
    m_nCurPageIdx = 0;
    UpdateTableDisplay();
}

void LogManage::BtnNextClicked()
{
    if( m_nCurPageIdx < m_nAllPageCnt-1 )
        ++m_nCurPageIdx;
    else
    {
        //m_pBtnNext->setEnabled(false);
    }
    UpdateTableDisplay();
}

void LogManage::BtnPrevClicked()
{
    if( m_nCurPageIdx >0 )
        --m_nCurPageIdx;
    {

    }
    UpdateTableDisplay();
}

void LogManage::BtnLastClicked()
{
    m_nCurPageIdx = m_nAllPageCnt-1;

    UpdateTableDisplay();
}

void LogManage::ComBRowNumChanged(int nIndex)
{
    UpdateAllPageCountInfo();
    UpdateTableDisplay();
}

