/********************************************************************************
** Form generated from reading UI file 'LogManage.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGMANAGE_H
#define UI_LOGMANAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LogManage
{
public:

    void setupUi(QWidget *LogManage)
    {
        if (LogManage->objectName().isEmpty())
            LogManage->setObjectName(QStringLiteral("LogManage"));
        LogManage->resize(1175, 721);

        retranslateUi(LogManage);

        QMetaObject::connectSlotsByName(LogManage);
    } // setupUi

    void retranslateUi(QWidget *LogManage)
    {
        LogManage->setWindowTitle(QApplication::translate("LogManage", "LogManage", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class LogManage: public Ui_LogManage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGMANAGE_H
