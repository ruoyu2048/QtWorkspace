#include "LogManage.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    app.addLibraryPath(QString("../LogManagePlugin")); // 添加库路径
    LogManage w;
    w.show();

    return app.exec();
}
