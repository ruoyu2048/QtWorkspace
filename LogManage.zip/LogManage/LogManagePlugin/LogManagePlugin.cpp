#include "LogManagePlugin.h"

ILogManage* LogManagePlugin::Clone()
{
    ILogManage * instance=new LogManagePlugin();
    return instance ;
}

QObject* LogManagePlugin::CreateInstance()
{
        QObject* instance=new LogManagePlugin();
        return instance;
}

