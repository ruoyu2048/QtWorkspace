#ifndef PLUGIN_H
#define PLUGIN_H

#include <QObject>
#include <QDebug>
#include "../LogManage/ILogManage.h"

class LogManagePlugin : public QObject,ILogManage
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LogManageInterface_iid FILE "LogManagePlugin.json")
    Q_INTERFACES(ILogManage)
public:
    ILogManage* Clone();
    QObject* CreateInstance();
private:

};

#endif // PLUGIN_H
