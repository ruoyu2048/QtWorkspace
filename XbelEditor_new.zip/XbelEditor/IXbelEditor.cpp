﻿#include "IXbelEditor.h"

IXbelEditor::IXbelEditor(QWidget *parent) : QWidget(parent),m_pXbelTree(nullptr)
{

}

IXbelEditor::~IXbelEditor(){

}
