#include "widget.h"
#include <QtPlugin>
#include <QApplication>
#include <QWidget>
#include <QPluginLoader>
#include <QString>
#include <QtDebug>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    app.addLibraryPath(QString("../plugin")); // 添加库路径
    Widget w;
    w.show();
     return app.exec();

}
