#ifndef INTERFACE_H
#define INTERFACE_H
#include <QWidget>
#include <QtPlugin>
#define pluginInterface_iid "io.qt.dynamicplugin"
class PluginInterface
{
public:
    virtual ~PluginInterface() {}
    virtual void ShowValue() = 0;
    virtual int Add(int) = 0 ;  // 正确写法
    virtual  void Set(int )=0;
    virtual  int Get()=0;
    virtual PluginInterface* Clone()=0;
    virtual QObject* CreateInstance()=0;
};


Q_DECLARE_INTERFACE(PluginInterface, pluginInterface_iid)
#endif // INTERFACE_H
