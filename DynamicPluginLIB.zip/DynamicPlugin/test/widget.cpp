#include "widget.h"
#include "ui_widget.h"
#include "interface.h"
#include <QtPlugin>
#include <QApplication>
#include <QWidget>
#include <QPluginLoader>
#include <QString>
#include <QtDebug>
#include <iostream>
using namespace std;
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    QObject* object ;
    // 加载插件，取得实例
    QPluginLoader l(QString("Plugin.dll")) ;


    if ( (object=l.instance()) != NULL )
    {
        qDebug("plugin loaded .");
        // 使用插件
        int value=9;
        PluginInterface* plugin = qobject_cast<PluginInterface*>(object) ;


        if (plugin)
        {
            cout<<"plugin 1"<<plugin<<endl;
            PluginInterface* plugin_clone=plugin->Clone();
            cout<<"plugin 2"<<plugin_clone<<endl;
            qDebug("plugin 1 num=%d",plugin->Get());
            qDebug("plugin 1 num+%d=%d",value,plugin->Add(value));
            qDebug("plugin 1 num+%d=%d",value,plugin->Add(value));
            qDebug("plugin 1 num=%d",plugin->Get());


            qDebug("plugin 2 num=%d",plugin_clone->Get());
            qDebug("plugin 2 num+%d=%d",value,plugin_clone->Add(value));
            qDebug("plugin 2 num=%d",plugin_clone->Get());
            qDebug("plugin 2");

        }

    }
    else
    {
        qDebug("failed to load plugin !! ");
        QString errorStr = l.errorString();
        qDebug()<<errorStr;
    }
}
