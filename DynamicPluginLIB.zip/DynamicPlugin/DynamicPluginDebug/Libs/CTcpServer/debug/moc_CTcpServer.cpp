/****************************************************************************
** Meta object code from reading C++ file 'CTcpServer.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../Libs/CTcpServer/CTcpServer.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CTcpServer.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CTcpServer_t {
    QByteArrayData data[9];
    char stringdata0[87];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CTcpServer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CTcpServer_t qt_meta_stringdata_CTcpServer = {
    {
QT_MOC_LITERAL(0, 0, 10), // "CTcpServer"
QT_MOC_LITERAL(1, 11, 12), // "slotReadData"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 7), // "qintptr"
QT_MOC_LITERAL(4, 33, 6), // "handle"
QT_MOC_LITERAL(5, 40, 14), // "unsigned char*"
QT_MOC_LITERAL(6, 55, 6), // "rcvBuf"
QT_MOC_LITERAL(7, 62, 7), // "nRcvLen"
QT_MOC_LITERAL(8, 70, 16) // "slotDisconnected"

    },
    "CTcpServer\0slotReadData\0\0qintptr\0"
    "handle\0unsigned char*\0rcvBuf\0nRcvLen\0"
    "slotDisconnected"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CTcpServer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    3,   24,    2, 0x08 /* Private */,
       8,    1,   31,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5, QMetaType::Int,    4,    6,    7,
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

void CTcpServer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CTcpServer *_t = static_cast<CTcpServer *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->slotReadData((*reinterpret_cast< qintptr(*)>(_a[1])),(*reinterpret_cast< unsigned char*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->slotDisconnected((*reinterpret_cast< qintptr(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject CTcpServer::staticMetaObject = {
    { &QTcpServer::staticMetaObject, qt_meta_stringdata_CTcpServer.data,
      qt_meta_data_CTcpServer,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *CTcpServer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CTcpServer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CTcpServer.stringdata0))
        return static_cast<void*>(const_cast< CTcpServer*>(this));
    return QTcpServer::qt_metacast(_clname);
}

int CTcpServer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpServer::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_CTcpSocket_t {
    QByteArrayData data[11];
    char stringdata0[123];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CTcpSocket_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CTcpSocket_t qt_meta_stringdata_CTcpSocket = {
    {
QT_MOC_LITERAL(0, 0, 10), // "CTcpSocket"
QT_MOC_LITERAL(1, 11, 14), // "signalSendData"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 7), // "qintptr"
QT_MOC_LITERAL(4, 35, 6), // "handle"
QT_MOC_LITERAL(5, 42, 14), // "unsigned char*"
QT_MOC_LITERAL(6, 57, 7), // "sendBuf"
QT_MOC_LITERAL(7, 65, 8), // "nSendLen"
QT_MOC_LITERAL(8, 74, 18), // "signalDisconnected"
QT_MOC_LITERAL(9, 93, 12), // "slotReadData"
QT_MOC_LITERAL(10, 106, 16) // "slotDisconnected"

    },
    "CTcpSocket\0signalSendData\0\0qintptr\0"
    "handle\0unsigned char*\0sendBuf\0nSendLen\0"
    "signalDisconnected\0slotReadData\0"
    "slotDisconnected"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CTcpSocket[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    3,   34,    2, 0x06 /* Public */,
       8,    1,   41,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    0,   44,    2, 0x0a /* Public */,
      10,    0,   45,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5, QMetaType::Int,    4,    6,    7,
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CTcpSocket::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CTcpSocket *_t = static_cast<CTcpSocket *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalSendData((*reinterpret_cast< qintptr(*)>(_a[1])),(*reinterpret_cast< unsigned char*(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 1: _t->signalDisconnected((*reinterpret_cast< qintptr(*)>(_a[1]))); break;
        case 2: _t->slotReadData(); break;
        case 3: _t->slotDisconnected(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (CTcpSocket::*_t)(qintptr , unsigned char * , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTcpSocket::signalSendData)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (CTcpSocket::*_t)(qintptr );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTcpSocket::signalDisconnected)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject CTcpSocket::staticMetaObject = {
    { &QTcpSocket::staticMetaObject, qt_meta_stringdata_CTcpSocket.data,
      qt_meta_data_CTcpSocket,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *CTcpSocket::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CTcpSocket::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CTcpSocket.stringdata0))
        return static_cast<void*>(const_cast< CTcpSocket*>(this));
    return QTcpSocket::qt_metacast(_clname);
}

int CTcpSocket::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTcpSocket::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void CTcpSocket::signalSendData(qintptr _t1, unsigned char * _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CTcpSocket::signalDisconnected(qintptr _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
