#ifndef CUDP_GLOBAL_H
#define CUDP_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(CUDP_LIBRARY)
#  define CUDPSHARED_EXPORT Q_DECL_EXPORT
#else
#  define CUDPSHARED_EXPORT Q_DECL_IMPORT
#endif

#endif // CUDP_GLOBAL_H
