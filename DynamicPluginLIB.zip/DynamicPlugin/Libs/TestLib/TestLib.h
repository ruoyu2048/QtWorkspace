#ifndef TESTLIB_H
#define TESTLIB_H

#include <QObject>
#include "testlib_global.h"

class TESTLIBSHARED_EXPORT TestLib:public QObject
{
    Q_OBJECT
public:
    explicit TestLib(QObject *parent = nullptr);
    void Display(QString strMsg);

signals:

public slots:

};

#endif // TESTLIB_H
