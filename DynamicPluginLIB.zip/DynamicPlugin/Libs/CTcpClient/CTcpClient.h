#ifndef CTCPCLIENT_H
#define CTCPCLIENT_H
/*-----------------------------------------------------------*/
/*-------------------------Used Demo-------------------------*/
/*-----------------------------------------------------------*/
/*
 *(1)Add the headers in *.pro file
    HEADERS += \
        Libs/CTcpClient/CTcpClient.h \
        Libs/CTcpServer/CTcpServer.h \
        Libs/CUdp/CUdp.h \
        Libs/DataStruct/DataStruct.h


    LIBS += "./CTcpClient.dll" \
            "./CTcpServer.dll" \
            "./CUdp.dll"
   (2)Test Demo
    #include <QCoreApplication>

    #include "./Libs/CTcpClient/CTcpClient.h"
    #include "./Libs/CTcpServer/CTcpServer.h"
    #include "./Libs/CUdp/CUdp.h"

    #include <QLibrary>

    int main(int argc, char *argv[])
    {
        QCoreApplication a(argc, argv);
        QLibrary lary("CTcpServer.dll");
        lary.load();
        QLibrary lary2("CTcpClient.dll");
        lary2.load();
        QLibrary lary3("CUdp.dll");
        lary3.load();
        CTcpServer* m_pTS = new CTcpServer();
        m_pTS->StartListen("127.0.0.1",10086);

        CTcpClient* m_pTC0 = new CTcpClient();
        CTcpClient* m_pTC1 = new CTcpClient();
        m_pTC0->ConnectToHost("127.0.0.1",10086);
        m_pTC1->ConnectToHost("127.0.0.1",10086);

        CUdp* m_pUDPServer = new CUdp();
        m_pUDPServer->Bind(QHostAddress::LocalHost,10001);

        CUdp* m_pUDPClient = new CUdp();
        m_pUDPClient->Bind(QHostAddress::LocalHost,10002);
        m_pUDPClient->StartTest();

        return a.exec();
    }
*/
/*-----------------------------------------------------------*/

#include <QObject>
#include <QTimer>
#include <QTcpSocket>
#include "ctcpclient_global.h"
#include "../PubDef/DataStruct.h"

class CTCPCLIENTSHARED_EXPORT CTcpClient:public QObject
{
    Q_OBJECT
public:
    explicit CTcpClient(QObject *parent = nullptr);

    /************************************************************************
    *函数名:	ConnectToHost
    *概述:连接到服务端
    *参数：strServerIP--服务端IP地址
    *     nServerPort--服务端端口
    *返回值：如果连接成功，则返回true，否则返回false.
    ************************************************************************/
    bool ConnectToHost(QString strServerIP,quint16 nServerPort);

    /************************************************************************
    *函数名:	SendData
    *概述:发送报文
    *参数：sendBuf--要发送的报文
    *     nSendLen--要发送报文的长度
    *返回值：如果发送成功，则返回true，否则返回false.
    ************************************************************************/
    bool SendData(unsigned char* sendBuf,int nSendLen);

    /************************************************************************
    *函数名:	Close
    *概述:关闭客户端
    *参数：无
    *返回值：无
    ************************************************************************/
    void Close();
private:
    /************************************************************************
    *函数名:	StartTest
    *概述:定时发送报文测试
    *参数：无
    *返回值：无
    ************************************************************************/
    void StartTest();

private:
    QByteArray  mCacheAry;      //报文缓存
    QTcpSocket* m_pTSClient;    //客户端TcpSocket
    qintptr mSocketDecriptor;   //客户端TcpSocket描述符(保留)

    //TEST
    QTimer* m_pTimer;           //发送报文定时器

signals:
    /************************************************************************
    *函数名:	UpdateConnectState
    *概述:发送客户端连接状态信息。
    *参数：strConnectState--连接状态描述符(准备连接、正在连接、连接超时、已连接、断开连接)
    *返回值：无
    ************************************************************************/
    void UpdateConnectState(QString strConnectState);
    /************************************************************************
    *函数名:	UpdateConnectState
    *概述:发送客户端连接状态信息。
    *参数：emConnType--连接状态枚举
    *返回值：无
    ************************************************************************/
    void UpdateConnectState(ConnType emConnType);

public slots:

private slots:
    /************************************************************************
    *函数名:	ReadData
    *概述:接收报文槽行数
    *参数：无
    *返回值：无
    ************************************************************************/
    void ReadData();

    /************************************************************************
    *函数名:	Connected
    *概述:TCP客户端与服务端已连接槽函数
    *参数：无
    *返回值：无
    ************************************************************************/
    void Connected();

    /************************************************************************
    *函数名:	Disconnected
    *概述:TCP客户端与服务端断开槽函数
    *参数：无
    *返回值：无
    ************************************************************************/
    void Disconnected();

    /************************************************************************
    *函数名:	DisplayError
    *概述:TCP客户端错误信息显示槽函数
    *参数：无
    *返回值：无
    ************************************************************************/
    void DisplayError(QAbstractSocket::SocketError socketError);

    //TEST
    /************************************************************************
    *函数名:	SendDataTest
    *概述:定时发送报文测试函数。
    *参数：无
    *返回值：无
    ************************************************************************/
    void SendDataTest();
};

#endif // CTCPCLIENT_H

