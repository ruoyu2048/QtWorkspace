#ifndef TESTSLIB_H
#define TESTSLIB_H

#include <QObject>

class  TestSLib:public QObject
{
    Q_OBJECT
public:
    explicit TestSLib(QObject *parent = nullptr);
    void Display(QString strMsg);

signals:

public slots:

};

#endif // TESTSLIB_H
