#include "TestSLib.h"
#include <QDebug>


TestSLib::TestSLib(QObject *parent) : QObject(parent)
{
}

void TestSLib::Display(QString strMsg)
{
    qDebug()<<strMsg;
}
