#ifndef CTCPSERVER_H
#define CTCPSERVER_H
/*-----------------------------------------------------------*/
/*-------------------------Used Demo-------------------------*/
/*-----------------------------------------------------------*/
/*
 *(1)Add the headers in *.pro file
    HEADERS += \
        Libs/CTcpClient/CTcpClient.h \
        Libs/CTcpServer/CTcpServer.h \
        Libs/CUdp/CUdp.h \
        Libs/DataStruct/DataStruct.h


    LIBS += "./CTcpClient.dll" \
            "./CTcpServer.dll" \
            "./CUdp.dll"
   (2)Test Demo
    #include <QCoreApplication>

    #include "./Libs/CTcpClient/CTcpClient.h"
    #include "./Libs/CTcpServer/CTcpServer.h"
    #include "./Libs/CUdp/CUdp.h"

    #include <QLibrary>

    int main(int argc, char *argv[])
    {
        QCoreApplication a(argc, argv);
        QLibrary lary("CTcpServer.dll");
        lary.load();
        QLibrary lary2("CTcpClient.dll");
        lary2.load();
        QLibrary lary3("CUdp.dll");
        lary3.load();
        CTcpServer* m_pTS = new CTcpServer();
        m_pTS->StartListen("127.0.0.1",10086);

        CTcpClient* m_pTC0 = new CTcpClient();
        CTcpClient* m_pTC1 = new CTcpClient();
        m_pTC0->ConnectToHost("127.0.0.1",10086);
        m_pTC1->ConnectToHost("127.0.0.1",10086);

        CUdp* m_pUDPServer = new CUdp();
        m_pUDPServer->Bind(QHostAddress::LocalHost,10001);

        CUdp* m_pUDPClient = new CUdp();
        m_pUDPClient->Bind(QHostAddress::LocalHost,10002);
        m_pUDPClient->StartTest();

        return a.exec();
    }
*/
/*-----------------------------------------------------------*/
//#include <QObject>
#include <QMap>
#include <QTcpServer>
#include <QTcpSocket>
#include "ctcpserver_global.h"
#include "../PubDef/DataStruct.h"

class  CTcpSocket;
class CTCPSERVERSHARED_EXPORT CTcpServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit CTcpServer(QObject *parent = nullptr);

    /************************************************************************
    *函数名:	StartListen
    *概述:启动TCP Server侦听
    *参数：strHostIP--TCP服务端IP地址
    *     nHostPort--TCP服务端端口
    *返回值：如果启动成功，则返回true，否则返回false
    ************************************************************************/
    bool StartListen(QString strServerIP,quint16 nServerPort);

    /************************************************************************
    *函数名:	SendData
    *概述:向客户端发送数据报文
    *参数：handle--目标套接字标识符
    *     sendBuf--发送报文
    *     nSendLen--发送报文长度
    *返回值：如果启动成功，则返回true，否则返回false
    ************************************************************************/
    bool SendData(qintptr handle,unsigned char* sendBuf,int nSendLen);

    /************************************************************************
    *函数名:	StopListen
    *概述:关闭服务端
    *参数：无
    *返回值：无
    ************************************************************************/
    void StopListen();
protected:
    /************************************************************************
    *函数名:	incomingConnection
    *概述:基类函数
    *参数：handle--连入的客户端套接字标识符
    *返回值：无
    ************************************************************************/
    void incomingConnection(qintptr handle);

private:
    /************************************************************************
    *变量名:	mClientsMap
    *概述:连入客户端存储映射
    * Key:连入的客户端套接字标识符
    * Value:自定义TCP套接字对象
    ************************************************************************/
    QMap<qintptr,CTcpSocket*>mClientsMap;


signals:

public slots:

private slots:
    /************************************************************************
    *函数名:	slotReadData
    *概述:读取客户端发送的数据
    *参数：handle--客户端套接字标识符
    *     rcvBuf--客户端发送的报文
    *     nRcvLen--客户端发送的报文长度
    *返回值：无
    ************************************************************************/
    void slotReadData(qintptr handle,unsigned char* rcvBuf,int nRcvLen);

    /************************************************************************
    *函数名:	slotDisconnected
    *概述:接收客户端断开连接的信号
    *参数：handle--客户端套接字标识符
    *返回值：无
    ************************************************************************/
    void slotDisconnected(qintptr handle);

};

class CTCPSERVERSHARED_EXPORT CTcpSocket : public QTcpSocket
{
    Q_OBJECT
public:
    explicit CTcpSocket(QObject *parent = nullptr);

    //Only used in TcpServer
    /************************************************************************
    *函数名:	SaveSocketDecriptor
    *概述:将该套接字的描述符保存到成员变量，在TCPSever中要用到。
    *参数：无
    *返回值：无
    ************************************************************************/
    void SaveSocketDecriptor();

    /************************************************************************
    *函数名:	DisplaySocketDecriptor
    *概述:打印套接字描述符(测试)。
    *参数：无
    *返回值：无
    ************************************************************************/
    void DisplaySocketDecriptor();

    /************************************************************************
    *函数名:	SendData
    *概述:发送报文
    *参数：sendBuf--要发送的报文
    *     nSendLen--要发送报文的长度
    *返回值：如果发送成功，则返回true，否则返回false.
    ************************************************************************/
    bool SendData(unsigned char* sendBuf,int nSendLen);
private:
    //套接字描述符
    qintptr mSocketDecriptor;
    //接收数据缓存
    QByteArray mCacheAry;

signals:
    //Only used in TcpServer
    /************************************************************************
    *函数名:	signalSendData
    *概述:发送报文信号
    *参数：handle--客户端套接字描述符
    *     sendBuf--要发送的报文
    *     nSendLen--要发送报文的长度
    *返回值：如果发送成功，则返回true，否则返回false.
    ************************************************************************/
    void signalSendData(qintptr handle,unsigned char* sendBuf,int nSendLen);

    /************************************************************************
    *函数名:	signalDisconnected
    *概述:发送客户端断开连接的信号
    *参数：handle--客户端套接字标识符
    *返回值：无
    ************************************************************************/
    void signalDisconnected(qintptr handle);

public slots:
    /************************************************************************
    *函数名:	slotReadData
    *概述:客户端解析报文槽函数
    *参数：无
    *返回值：无
    ************************************************************************/
    void slotReadData();

    /************************************************************************
    *函数名:	slotDisconnected
    *概述:客户端断开连接槽函数
    *参数：无
    *返回值：无
    ************************************************************************/
    void slotDisconnected();
};

#endif // CTCPSERVER_H
