#ifndef DATASTRUCT_H
#define DATASTRUCT_H

enum ConnType{
    Ready,
    Connecting,
    Timeout,
    Connected,
    Disconnected
};

struct FrameHead{
    char cHead;             //帧头
    char cDesAdd;           //目的地址
    char cSrcAdd;           //原地址
    char cType;             //消息类型
    int  iLenth;            //信息区长度

    FrameHead(){
        //memset(this,0,sizeof(FrameHead));
        memset(&cHead,0,sizeof(FrameHead));
        cHead = 0xAA;
    }
};

struct FrameTail{
    char cCheck;        //校验位
    char cTail;         //包尾
    FrameTail(){
        memset(&cCheck,0,sizeof(FrameTail));
        cTail = 0xA5;
    }
};

//中频源(Mid)
struct MidInfo{
    char cLDState;          //雷达状态
    char cWorkMode;         //工作模式
    char cPulseInput;       //脉冲输入
    char cOLMid;            //中频源输出幅度(Output Level of Mid)
    char cDSMid;            //设备状态(Device of Mid)
    char cReserve[4];       //备用
    MidInfo(){
        memset(&cLDState,0,sizeof(MidInfo));
    }
};


#endif // DATASTRUCT_H
