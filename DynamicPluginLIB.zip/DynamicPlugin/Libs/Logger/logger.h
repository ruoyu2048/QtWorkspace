#ifndef LOGGER_H
#define LOGGER_H

#include "logger_global.h"

class LOGGERSHARED_EXPORT Logger
{

public:
    Logger();
};

#endif // LOGGER_H
