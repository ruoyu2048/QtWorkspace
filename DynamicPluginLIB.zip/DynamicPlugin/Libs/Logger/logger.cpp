#include "logger.h"


Logger::Logger()
{
}
