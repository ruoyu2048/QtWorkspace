#include "plugin.h"
#include <QDebug>
#include <QMessageBox>

void plugin::ShowValue()
{
    QMessageBox msg_box;
    msg_box.setText(QString::number(num));
    msg_box.show();
}
int plugin::Add(int value)
{
    testSLib.Display("AAAA");
    if( false == dbTest.OpenDB("../Test.db") )
    {
        qDebug()<<"Open db failed!";
    }
    num=num+value;
    return num ;
}
void plugin::Set(int value)
{
        testSLib.Display("AAAA");
    num=value;
}

int plugin::Get()
{
        testSLib.Display("AAAA");
    return num;
}
PluginInterface* plugin::Clone()
{
    PluginInterface * instance=new plugin();
    return instance ;
}

QObject* plugin::CreateInstance()
{
        QObject* instance=new plugin();
        return instance;
}
