#include "staticlibtest.h"


StaticLibTest::StaticLibTest()
{
}
