#ifndef STATICLIBTEST_H
#define STATICLIBTEST_H


class StaticLibTest
{

public:
    StaticLibTest();
};

#endif // STATICLIBTEST_H
