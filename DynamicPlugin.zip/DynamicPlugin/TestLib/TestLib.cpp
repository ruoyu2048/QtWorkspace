#include "TestLib.h"
#include <QDebug>


TestLib::TestLib(QObject *parent) : QObject(parent)
{
}

void TestLib::Display(QString strMsg)
{
    qDebug()<<strMsg;
}
