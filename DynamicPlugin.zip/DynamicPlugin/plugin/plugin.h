#ifndef PLUGIN_H
#define PLUGIN_H

#include <QObject>
#include <QDebug>
#include "TestLib.h"
#include "../test/interface.h"
class plugin : public QObject,PluginInterface
{


    Q_OBJECT
    Q_PLUGIN_METADATA(IID pluginInterface_iid FILE "plugin.json")
    Q_INTERFACES(PluginInterface)
public:
     PluginInterface* Clone();

    void ShowValue();
    int Get();
    int Add(int);
    void Set(int);
    QObject* CreateInstance();
private:
    int num=0;
    TestLib testLib;
};

#endif // PLUGIN_H
