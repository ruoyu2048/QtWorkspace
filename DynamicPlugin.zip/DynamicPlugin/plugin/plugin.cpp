#include "plugin.h"
#include <QMessageBox>

void plugin::ShowValue()
{
    QMessageBox msg_box;
    msg_box.setText(QString::number(num));
    msg_box.show();
}
int plugin::Add(int value)
{
    num=num+value;
    return num ;
}
void plugin::Set(int value)
{
    num=value;
    testLib.Display("AAAA");
}

int plugin::Get()
{
    return num;
}
PluginInterface* plugin::Clone()
{
    PluginInterface * instance=new plugin();
    return instance ;
}

QObject* plugin::CreateInstance()
{
        QObject* instance=new plugin();
        return instance;
}
