#include "dynamiclibtest.h"


DynamicLibTest::DynamicLibTest()
{
}
