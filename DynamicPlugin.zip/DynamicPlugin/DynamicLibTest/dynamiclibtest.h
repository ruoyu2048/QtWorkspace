#ifndef DYNAMICLIBTEST_H
#define DYNAMICLIBTEST_H

#include "dynamiclibtest_global.h"

class DYNAMICLIBTESTSHARED_EXPORT DynamicLibTest
{

public:
    DynamicLibTest();
};

#endif // DYNAMICLIBTEST_H
